package dev.android.anotheriptvplayer.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFF00E5FF)
val PurpleGrey80 = Color(0xFF062145)
val Pink80 = Color(0xFFFFB800)

val Purple40 = Color(0xFF00E5FF)
val PurpleGrey40 = Color(0xFF04142D)
val Pink40 = Color(0xFFFFB800)

val GoldnxNavy = Color(0xFF04142D)
val GoldnxNavyAlt = Color(0xFF062145)
val GoldnxGold = Color(0xFFFFB800)
val GoldnxCyan = Color(0xFF00E5FF)
val GoldnxWhite = Color(0xFFFFFFFF)

val GoldNXNavy = Color(0xFF04142D)
val GoldNXNavyAlt = Color(0xFF062145)
val GoldNXGold = Color(0xFFFFB800)
val GoldNXCyan = Color(0xFF00E5FF)
