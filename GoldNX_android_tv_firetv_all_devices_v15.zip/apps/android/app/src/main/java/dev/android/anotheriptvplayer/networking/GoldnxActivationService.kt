package dev.android.anotheriptvplayer.networking

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object GoldnxActivationService {
    private const val API_URL = "https://goldnx.de/api/activate.php"

    suspend fun activate(code: String, deviceId: String): String = withContext(Dispatchers.IO) {
        val cleanCode = code.trim().uppercase()
        if (cleanCode.isEmpty()) error("Aktivasyon kodu boş olamaz")

        val body = "code=" + URLEncoder.encode(cleanCode, "UTF-8") +
            "&device_id=" + URLEncoder.encode(deviceId, "UTF-8")

        val conn = (URL(API_URL).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 25000
            doOutput = true
            setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "GoldNX-Player-Android")
        }

        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

        val response = try {
            val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
            stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            conn.disconnect()
        }

        val json = try {
            JSONObject(response)
        } catch (e: Throwable) {
            error("API JSON döndürmedi: " + response.take(120))
        }

        val success = json.optBoolean("success", false) ||
            json.optString("success") == "1" ||
            json.optString("status").equals("success", ignoreCase = true)

        if (!success) {
            error(json.optString("message", json.optString("error", "Kod doğrulanamadı")))
        }

        val m3u = listOf("m3u8", "m3u", "url", "playlist", "link", "stream")
            .firstNotNullOfOrNull { key -> json.optString(key, "").trim().takeIf { it.isNotEmpty() } }

        if (m3u.isNullOrEmpty()) {
            error("API başarılı ama M3U8 linki dönmedi. Beklenen alan: m3u8")
        }

        m3u
    }
}
