package dev.android.anotheriptvplayer.networking

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object GoldnxActivationService {
    private const val API_URL = "https://goldnx.de/api/activate.php"

    suspend fun activate(code: String, deviceId: String): String = withContext(Dispatchers.IO) {
        val cleanCode = code.trim().uppercase()
        if (cleanCode.isEmpty()) error("Aktivasyon kodu boş olamaz")

        val body = "code=" + URLEncoder.encode(cleanCode, "UTF-8") +
            "&device_id=" + URLEncoder.encode(deviceId, "UTF-8")

        val conn = (URL(API_URL).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 20000
            doOutput = true
            setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
            setRequestProperty("Accept", "application/json")
        }

        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val response = try {
            val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
            stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            conn.disconnect()
        }

        val json = JSONObject(response)
        if (!json.optBoolean("success", false)) {
            error(json.optString("message", "Kod doğrulanamadı"))
        }

        val m3u8 = json.optString("m3u8", "").trim()
        if (m3u8.isEmpty()) error("Bu koda ait M3U8 linki bulunamadı")
        m3u8
    }
}
