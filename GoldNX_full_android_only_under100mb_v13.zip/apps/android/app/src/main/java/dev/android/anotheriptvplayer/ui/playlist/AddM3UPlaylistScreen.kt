package dev.android.anotheriptvplayer.ui.playlist

import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import dev.android.anotheriptvplayer.AnotherIptvPlayerApp
import dev.android.anotheriptvplayer.model.Playlist
import dev.android.anotheriptvplayer.model.PlaylistKind
import dev.android.anotheriptvplayer.networking.GoldnxActivationService
import dev.android.anotheriptvplayer.networking.M3UParser
import dev.android.anotheriptvplayer.networking.M3UParserException
import dev.android.anotheriptvplayer.networking.M3UService
import dev.android.anotheriptvplayer.networking.M3UServiceException
import dev.android.anotheriptvplayer.ui.LocalPlaylistRepository
import dev.android.anotheriptvplayer.ui.components.ModalSlideContainer
import dev.android.anotheriptvplayer.ui.components.SavingOverlay
import kotlinx.coroutines.launch
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddM3UPlaylistScreen(
    onCancel: () -> Unit,
    onSaved: (String) -> Unit,
    editingPlaylistId: String? = null,
) {
    val repository = LocalPlaylistRepository.current
    val context = LocalContext.current
    val app = context.applicationContext as AnotherIptvPlayerApp
    val focusManager = LocalFocusManager.current
    val scope = rememberCoroutineScope()

    var code by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("GoldNX") }
    var isSaving by remember { mutableStateOf(false) }
    var importStatus by remember { mutableStateOf("Kod kontrol ediliyor") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val isValid = code.trim().length >= 4

    fun save() {
        if (!isValid || isSaving) return
        focusManager.clearFocus()
        errorMessage = null
        isSaving = true
        importStatus = "Kod kontrol ediliyor"

        scope.launch {
            try {
                val deviceId = Settings.Secure.getString(
                    context.contentResolver,
                    Settings.Secure.ANDROID_ID
                ) ?: "android-device"

                val cleanCode = code.trim().uppercase()
                val m3u8Url = GoldnxActivationService.activate(cleanCode, deviceId)

                importStatus = "M3U8 bağlantısı indiriliyor"
                val service = M3UService(contentResolver = context.contentResolver)
                val rawText = service.fetchRemote(m3u8Url)

                importStatus = "Liste hazırlanıyor"
                val parsed = M3UParser.parseAsync(rawText)

                val playlistName = name.trim().ifEmpty { "GoldNX $cleanCode" }
                val playlist = Playlist.create(
                    id = UUID.randomUUID().toString(),
                    name = playlistName,
                    serverUrl = m3u8Url,
                    kind = PlaylistKind.M3U,
                    m3uEpgUrl = parsed.epgUrl,
                    createdAt = System.currentTimeMillis(),
                )

                repository.add(playlist)

                importStatus = "Kanallar kaydediliyor"
                app.m3uImporter.replace(
                    playlist = playlist,
                    channels = parsed.channels,
                    epgUrl = parsed.epgUrl,
                    clearServerUrl = false,
                )

                isSaving = false
                onSaved(playlist.id)
            } catch (t: Throwable) {
                isSaving = false
                errorMessage = when (t) {
                    is M3UServiceException.InvalidUrl -> "Bu koda ait M3U8 linki geçersiz."
                    is M3UServiceException.Network -> "Bağlantı hatası: ${t.message.orEmpty()}"
                    is M3UServiceException.Server -> "M3U8 sunucusu HTTP ${t.code} döndürdü."
                    is M3UServiceException.FileRead -> "Dosya okunamadı."
                    is M3UParserException.Empty -> "M3U8 listesi boş."
                    is M3UParserException.NoChannelsFound -> "M3U8 içinde oynatılabilir kanal bulunamadı."
                    else -> t.message ?: t.javaClass.simpleName
                }
            }
        }
    }

    ModalSlideContainer {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("GoldNX Kod Girişi") },
                    navigationIcon = {
                        IconButton(onClick = onCancel, enabled = !isSaving) {
                            Icon(Icons.Default.Close, contentDescription = "Kapat")
                        }
                    },
                )
            },
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Text(
                    text = "Aktivasyon Kodunu Gir",
                    style = MaterialTheme.typography.headlineSmall,
                )
                Text(
                    text = "GoldNX web sitesinden oluşturduğun kodu yaz. Kullanıcı adı veya şifre gerekmez.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )

                OutlinedTextField(
                    value = code,
                    onValueChange = {
                        code = it.uppercase()
                            .filter { ch -> ch.isLetterOrDigit() }
                            .take(16)
                    },
                    label = { Text("Aktivasyon Kodu") },
                    placeholder = { Text("Örn: G7NX42PA") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Characters,
                        keyboardType = KeyboardType.Ascii,
                        imeAction = ImeAction.Next,
                    ),
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Liste Adı") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Words,
                        imeAction = ImeAction.Done,
                    ),
                    keyboardActions = KeyboardActions(onDone = { save() }),
                )

                errorMessage?.let { msg ->
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(
                            text = msg,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.padding(14.dp),
                        )
                    }
                }

                Spacer(Modifier.height(6.dp))

                Button(
                    onClick = ::save,
                    enabled = isValid && !isSaving,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text("Kodla Giriş Yap")
                }

                Text(
                    text = "GoldNX yayın, kanal veya IPTV paketi satmaz. Kullanıcı kendi M3U8 bağlantısından sorumludur.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            if (isSaving) {
                SavingOverlay(importStatus)
            }
        }
    }
}
